
import React, { useState, useCallback } from 'react';
import Header from './components/Header';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import LessonPlanner from './components/LessonPlanner';
import Assessments from './components/Assessments';
import StudentEngagement from './components/StudentEngagement';
import Analytics from './components/Analytics';
import AIAssistant from './components/AIAssistant';
import LiveConversation from './components/LiveConversation';
import Chatbot from './components/Chatbot';
import type { ViewType } from './types';
import { GRADES, SUBJECTS, LANGUAGES } from './constants';

const App: React.FC = () => {
    const [currentView, setCurrentView] = useState<ViewType>('Dashboard');
    const [grade, setGrade] = useState<string>(GRADES[5]); // Default to Grade 6
    const [subject, setSubject] = useState<string>(SUBJECTS[1]); // Default to Science
    const [language, setLanguage] = useState<string>(LANGUAGES[0]); // Default to English

    const renderView = useCallback(() => {
        switch (currentView) {
            case 'Dashboard':
                return <Dashboard setView={setCurrentView} />;
            case 'Lesson Planner':
                return <LessonPlanner grade={grade} subject={subject} language={language} />;
            case 'Assessments':
                return <Assessments grade={grade} subject={subject} language={language} />;
            case 'Student Engagement':
                return <StudentEngagement />;
            case 'Analytics':
                return <Analytics />;
            case 'AI Assistant':
                return <AIAssistant />;
            case 'Live Conversation':
                return <LiveConversation />;
            case 'Chatbot':
                return <Chatbot />;
            default:
                return <Dashboard setView={setCurrentView} />;
        }
    }, [currentView, grade, subject, language]);

    return (
        <div className="flex h-screen bg-gray-50 text-gray-800">
            <Sidebar currentView={currentView} setCurrentView={setCurrentView} />
            <div className="flex flex-col flex-1 overflow-hidden">
                <Header 
                    grade={grade} setGrade={setGrade}
                    subject={subject} setSubject={setSubject}
                    language={language} setLanguage={setLanguage}
                />
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-100 p-4 md:p-8">
                    {renderView()}
                </main>
            </div>
        </div>
    );
};

export default App;