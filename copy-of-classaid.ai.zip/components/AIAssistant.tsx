import React, { useState, useRef, useCallback, useEffect } from 'react';
import type { ChatMessage } from '../types';
import { getChatResponse, transcribeAudio, textToSpeech } from '../services/geminiService';
import Card from './common/Card';
import Button from './common/Button';

// Audio decoding helpers for TTS
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}
async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}


const AIAssistant: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [thinkingMode, setThinkingMode] = useState(false);

    const [isRecording, setIsRecording] = useState(false);
    const [isSpeaking, setIsSpeaking] = useState<number | null>(null);
    const mediaRecorder = useRef<MediaRecorder | null>(null);
    const audioChunks = useRef<Blob[]>([]);
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim()) return;
        
        const userMessage: ChatMessage = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        setInput('');
        setIsLoading(true);

        const response = await getChatResponse(input, thinkingMode);
        const modelMessage: ChatMessage = { role: 'model', content: response };
        setMessages(prev => [...prev, modelMessage]);
        setIsLoading(false);
    };

    const handleMicToggle = async () => {
        if (isRecording) {
            mediaRecorder.current?.stop();
            setIsRecording(false);
        } else {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
                mediaRecorder.current = new MediaRecorder(stream);
                mediaRecorder.current.ondataavailable = (event) => {
                    audioChunks.current.push(event.data);
                };
                mediaRecorder.current.onstop = async () => {
                    const audioBlob = new Blob(audioChunks.current, { type: 'audio/webm' });
                    const reader = new FileReader();
                    reader.readAsDataURL(audioBlob);
                    reader.onloadend = async () => {
                        const base64String = reader.result?.toString().split(',')[1];
                        if (base64String) {
                            setIsLoading(true);
                            const transcript = await transcribeAudio(base64String, 'audio/webm');
                            setInput(transcript);
                            setIsLoading(false);
                        }
                    };
                    audioChunks.current = [];
                    stream.getTracks().forEach(track => track.stop());
                };
                mediaRecorder.current.start();
                setIsRecording(true);
            } catch (error) {
                console.error("Error accessing microphone:", error);
                alert("Could not access microphone. Please check your browser permissions.");
            }
        }
    };

    const handleSpeak = async (text: string, index: number) => {
        if (isSpeaking !== null) return;
        setIsSpeaking(index);
        const audioData = await textToSpeech(text.substring(0, 1000));
        if (audioData) {
            try {
                const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                const audioBuffer = await decodeAudioData(decode(audioData), audioContext, 24000, 1);
                const source = audioContext.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(audioContext.destination);
                source.onended = () => setIsSpeaking(null);
                source.start();
            } catch (error) {
                console.error("Error playing audio:", error);
                setIsSpeaking(null);
            }
        } else {
            setIsSpeaking(null);
        }
    };

    return (
        <div className="flex flex-col h-full max-h-[calc(100vh-120px)]">
            <div className="mb-4">
                <h1 className="text-3xl font-bold text-gray-900">AI Assistant</h1>
                <p className="mt-1 text-lg text-gray-600">Ask me anything about your curriculum, students, or for creative ideas!</p>
            </div>
            
            <Card className="flex-1 flex flex-col overflow-hidden">
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`p-3 rounded-lg max-w-lg ${msg.role === 'user' ? 'bg-indigo-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                                <p className="whitespace-pre-wrap">{msg.content}</p>
                                {msg.role === 'model' && (
                                    <button onClick={() => handleSpeak(msg.content, index)} disabled={isSpeaking !== null} className="mt-2 text-xs text-indigo-600 disabled:text-gray-400 font-semibold flex items-center">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-1"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                                        {isSpeaking === index ? 'Speaking...' : 'Read Aloud'}
                                    </button>
                                )}
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex justify-start">
                            <div className="p-3 rounded-lg bg-gray-200 text-gray-800">
                                <span className="animate-pulse">Thinking...</span>
                            </div>
                        </div>
                    )}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-4 border-t border-gray-200">
                     <div className="flex items-center justify-between mb-2">
                        <label htmlFor="thinking-mode" className="flex items-center cursor-pointer">
                            <div className="relative">
                                <input id="thinking-mode" type="checkbox" className="sr-only" checked={thinkingMode} onChange={() => setThinkingMode(!thinkingMode)} />
                                <div className="block bg-gray-300 w-10 h-6 rounded-full"></div>
                                <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${thinkingMode ? 'translate-x-full bg-indigo-600' : ''}`}></div>
                            </div>
                            <div className="ml-3 text-sm font-medium text-gray-700">
                                Thinking Mode <span className="text-xs text-gray-500">(for complex queries)</span>
                            </div>
                        </label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <textarea
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } }}
                            placeholder="Type your message or use the microphone..."
                            className="flex-grow w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 resize-none"
                            rows={1}
                        />
                        <Button onClick={handleMicToggle} variant="secondary" className={isRecording ? 'bg-red-500 text-white hover:bg-red-600' : ''}>
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>
                        </Button>
                        <Button onClick={handleSend} isLoading={isLoading}>Send</Button>
                    </div>
                </div>
            </Card>
        </div>
    );
};

export default AIAssistant;