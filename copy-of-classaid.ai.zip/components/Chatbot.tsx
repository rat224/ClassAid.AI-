import React, { useState, useRef, useEffect } from 'react';
import type { ChatMessage } from '../types';
import { getChatResponse } from '../services/geminiService';
import Card from './common/Card';
import Button from './common/Button';

const Chatbot: React.FC = () => {
    const [messages, setMessages] = useState<ChatMessage[]>([]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [thinkingMode, setThinkingMode] = useState(false);
    const chatEndRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, [messages]);

    const handleSend = async () => {
        if (!input.trim()) return;
        
        const userMessage: ChatMessage = { role: 'user', content: input };
        setMessages(prev => [...prev, userMessage]);
        const currentInput = input;
        setInput('');
        setIsLoading(true);

        const response = await getChatResponse(currentInput, thinkingMode);
        const modelMessage: ChatMessage = { role: 'model', content: response };
        setMessages(prev => [...prev, modelMessage]);
        setIsLoading(false);
    };

    return (
        <div className="flex flex-col h-full max-h-[calc(100vh-120px)]">
            <div className="mb-4">
                <h1 className="text-3xl font-bold text-gray-900">Chatbot</h1>
                <p className="mt-1 text-lg text-gray-600">A direct line to your AI assistant for quick questions.</p>
            </div>
            
            <Card className="flex-1 flex flex-col overflow-hidden">
                <div className="flex-1 p-4 overflow-y-auto space-y-4">
                    {messages.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`p-3 rounded-lg max-w-lg ${msg.role === 'user' ? 'bg-indigo-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                                <p className="whitespace-pre-wrap">{msg.content}</p>
                            </div>
                        </div>
                    ))}
                    {isLoading && (
                        <div className="flex justify-start">
                            <div className="p-3 rounded-lg bg-gray-200 text-gray-800">
                                <span className="animate-pulse">Thinking...</span>
                            </div>
                        </div>
                    )}
                    <div ref={chatEndRef} />
                </div>
                <div className="p-4 border-t border-gray-200">
                     <div className="flex items-center justify-between mb-2">
                        <label htmlFor="thinking-mode-chatbot" className="flex items-center cursor-pointer">
                            <div className="relative">
                                <input id="thinking-mode-chatbot" type="checkbox" className="sr-only" checked={thinkingMode} onChange={() => setThinkingMode(!thinkingMode)} />
                                <div className="block bg-gray-300 w-10 h-6 rounded-full"></div>
                                <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${thinkingMode ? 'translate-x-full bg-indigo-600' : ''}`}></div>
                            </div>
                            <div className="ml-3 text-sm font-medium text-gray-700">
                                Thinking Mode <span className="text-xs text-gray-500">(for complex queries)</span>
                            </div>
                        </label>
                    </div>
                    <div className="flex items-center space-x-2">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); handleSend(); } }}
                            placeholder="Type your message..."
                            className="flex-grow w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                        />
                        <Button onClick={handleSend} isLoading={isLoading}>Send</Button>
                    </div>
                </div>
            </Card>
        </div>
    );
};

export default Chatbot;
