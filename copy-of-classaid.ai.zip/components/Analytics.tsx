
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import Card from './common/Card';

const engagementData = [
    { name: 'Engaged', value: 75, fill: '#4CAF50' },
    { name: 'Distracted', value: 15, fill: '#FFC107' },
    { name: 'Confused', value: 10, fill: '#F44336' },
];

const performanceData = [
    { name: 'Jan', 'Avg. Score': 65 },
    { name: 'Feb', 'Avg. Score': 70 },
    { name: 'Mar', 'Avg. Score': 78 },
    { name: 'Apr', 'Avg. Score': 75 },
    { name: 'May', 'Avg. Score': 82 },
    { name: 'Jun', 'Avg. Score': 85 },
];

const Analytics: React.FC = () => {
    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">Class Analytics</h1>
                <p className="mt-1 text-lg text-gray-600">Track progress and gain insights into student performance.</p>
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Monthly Performance Average</h3>
                    <div className="h-80">
                         <ResponsiveContainer width="100%" height="100%">
                            <BarChart data={performanceData}>
                                <CartesianGrid strokeDasharray="3 3" />
                                <XAxis dataKey="name" />
                                <YAxis />
                                <Tooltip />
                                <Legend />
                                <Bar dataKey="Avg. Score" fill="#4f46e5" />
                            </BarChart>
                        </ResponsiveContainer>
                    </div>
                </Card>
                <Card>
                    <h3 className="text-lg font-semibold text-gray-800 mb-4">Engagement Distribution (Live)</h3>
                    <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                                <Pie
                                    data={engagementData}
                                    cx="50%"
                                    cy="50%"
                                    labelLine={false}
                                    outerRadius={100}
                                    fill="#8884d8"
                                    dataKey="value"
                                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                                >
                                    {engagementData.map((entry, index) => (
                                        <Cell key={`cell-${index}`} fill={entry.fill} />
                                    ))}
                                </Pie>
                                <Tooltip />
                            </PieChart>
                        </ResponsiveContainer>
                    </div>
                </Card>
            </div>
        </div>
    );
};

export default Analytics;
