
import React, { useState, useEffect } from 'react';
import type { Student } from '../types';
import Card from './common/Card';
import Button from './common/Button';
import Modal from './common/Modal';
import { generateEngagementSuggestion } from '../services/geminiService';

const MOCK_STUDENTS: Student[] = Array.from({ length: 16 }, (_, i) => ({
    id: i + 1,
    name: `Student ${i + 1}`,
    engagement: 'Engaged',
    avatar: `https://i.pravatar.cc/150?img=${i+1}`
}));

const ENGAGEMENT_STYLES = {
    'Engaged': 'border-green-500 bg-green-50',
    'Distracted': 'border-yellow-500 bg-yellow-50',
    'Confused': 'border-red-500 bg-red-50',
    'Helping Others': 'border-blue-500 bg-blue-50'
};

const StudentEngagement: React.FC = () => {
    const [students, setStudents] = useState<Student[]>(MOCK_STUDENTS);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [suggestion, setSuggestion] = useState('');
    const [isLoadingSuggestion, setIsLoadingSuggestion] = useState(false);

    useEffect(() => {
        const interval = setInterval(() => {
            setStudents(prevStudents => prevStudents.map(s => {
                const rand = Math.random();
                let newEngagement: Student['engagement'] = s.engagement;
                if (rand < 0.1) newEngagement = 'Distracted';
                else if (rand < 0.15) newEngagement = 'Confused';
                else if (rand < 0.2) newEngagement = 'Helping Others';
                else newEngagement = 'Engaged';
                return { ...s, engagement: newEngagement };
            }));
        }, 3000);
        return () => clearInterval(interval);
    }, []);

    const handleGetSuggestion = async () => {
        setIsModalOpen(true);
        setIsLoadingSuggestion(true);
        const newSuggestion = await generateEngagementSuggestion();
        setSuggestion(newSuggestion);
        setIsLoadingSuggestion(false);
    };
    
    return (
        <div className="space-y-6">
            <div className="flex justify-between items-center">
                <div>
                    <h1 className="text-3xl font-bold text-gray-900">Live Classroom View</h1>
                    <p className="mt-1 text-lg text-gray-600">Simulated real-time student engagement monitoring.</p>
                </div>
                <Button onClick={handleGetSuggestion}>Get AI Suggestion</Button>
            </div>

            <Card>
                <div className="grid grid-cols-2 sm:grid-cols-4 md:grid-cols-6 lg:grid-cols-8 gap-4">
                    {students.map(student => (
                        <div key={student.id} className="text-center">
                            <div className={`p-1 rounded-full border-4 ${ENGAGEMENT_STYLES[student.engagement]}`}>
                                <img src={student.avatar} alt={student.name} className="w-16 h-16 rounded-full mx-auto" />
                            </div>
                            <p className="text-xs mt-1 font-medium">{student.name}</p>
                            <p className="text-xs text-gray-500">{student.engagement}</p>
                        </div>
                    ))}
                </div>
            </Card>

            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="AI Engagement Suggestion">
                {isLoadingSuggestion ? (
                     <div className="flex justify-center items-center h-24">
                        <div className="w-8 h-8 border-2 border-indigo-200 border-t-indigo-600 rounded-full animate-spin"></div>
                    </div>
                ) : (
                    <p className="text-lg text-center text-gray-700 p-4">"{suggestion}"</p>
                )}
            </Modal>
        </div>
    );
};

export default StudentEngagement;
