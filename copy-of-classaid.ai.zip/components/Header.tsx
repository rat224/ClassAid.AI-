
import React, { useState } from 'react';
import { GRADES, SUBJECTS, LANGUAGES } from '../constants';

interface HeaderProps {
    grade: string;
    setGrade: (grade: string) => void;
    subject: string;
    setSubject: (subject: string) => void;
    language: string;
    setLanguage: (language: string) => void;
}

const Header: React.FC<HeaderProps> = ({ grade, setGrade, subject, setSubject, language, setLanguage }) => {
    const [isListening, setIsListening] = useState(false);

    const handleVoiceCommand = () => {
        setIsListening(prev => !prev);
        // Here you would integrate Web Speech API for Speech-to-Text
    };

    const Selector: React.FC<{ value: string; onChange: (e: React.ChangeEvent<HTMLSelectElement>) => void; options: string[]; className?: string }> = ({ value, onChange, options, className }) => (
        <select value={value} onChange={onChange} className={`bg-white border border-gray-300 rounded-md shadow-sm py-2 px-3 text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 ${className}`}>
            {options.map(opt => <option key={opt} value={opt}>{opt}</option>)}
        </select>
    );

    return (
        <header className="flex items-center justify-between h-20 bg-white px-4 md:px-8 border-b border-gray-200">
            <div className="flex items-center space-x-2 md:space-x-4">
                <Selector value={grade} onChange={(e) => setGrade(e.target.value)} options={GRADES} />
                <Selector value={subject} onChange={(e) => setSubject(e.target.value)} options={SUBJECTS} />
                <Selector value={language} onChange={(e) => setLanguage(e.target.value)} options={LANGUAGES} />
            </div>
            <div className="flex items-center space-x-4">
                <button 
                    onClick={handleVoiceCommand}
                    className={`p-2 rounded-full transition-colors ${isListening ? 'bg-red-500 text-white animate-pulse' : 'bg-gray-200 text-gray-600 hover:bg-indigo-100 hover:text-indigo-600'}`}
                    title="Use Voice Command"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"></path><path d="M19 10v2a7 7 0 0 1-14 0v-2"></path><line x1="12" y1="19" x2="12" y2="23"></line><line x1="8" y1="23" x2="16" y2="23"></line></svg>
                </button>
                <img className="h-10 w-10 rounded-full object-cover" src="https://picsum.photos/100" alt="Teacher Avatar" />
            </div>
        </header>
    );
};

export default Header;
