
import React from 'react';
import Card from './common/Card';
import Button from './common/Button';
import type { ViewType } from '../types';

interface DashboardProps {
    setView: (view: ViewType) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ setView }) => {
    return (
        <div className="space-y-8">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">Welcome back, Teacher!</h1>
                <p className="mt-1 text-lg text-gray-600">Here's your classroom at a glance.</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card className="bg-indigo-50 border-l-4 border-indigo-500">
                    <h3 className="text-lg font-semibold text-indigo-800">Today's Lesson</h3>
                    <p className="mt-2 text-2xl font-bold">Science: The Solar System</p>
                    <p className="text-sm text-gray-600">Grade 6</p>
                    <Button className="mt-4" onClick={() => setView('Lesson Planner')}>View Plan</Button>
                </Card>

                <Card className="bg-green-50 border-l-4 border-green-500">
                    <h3 className="text-lg font-semibold text-green-800">Student Engagement</h3>
                    <p className="mt-2 text-2xl font-bold">88% Actively Engaged</p>
                    <p className="text-sm text-gray-600">Real-time analysis</p>
                    <Button className="mt-4" variant="secondary" onClick={() => setView('Student Engagement')}>Monitor Class</Button>
                </Card>

                <Card className="bg-yellow-50 border-l-4 border-yellow-500">
                    <h3 className="text-lg font-semibold text-yellow-800">Upcoming Assessment</h3>
                    <p className="mt-2 text-2xl font-bold">Math: Fractions Quiz</p>
                    <p className="text-sm text-gray-600">Due this Friday</p>
                    <Button className="mt-4" variant="secondary" onClick={() => setView('Assessments')}>Prepare Quiz</Button>
                </Card>
            </div>

            <div>
                <h2 className="text-2xl font-bold text-gray-800 mb-4">Quick Actions</h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <button onClick={() => setView('Lesson Planner')} className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg hover:bg-indigo-50 transition-all flex flex-col items-center justify-center space-y-2">
                        <span className="text-indigo-500">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" /><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" /></svg>
                        </span>
                        <span className="font-semibold">New Lesson</span>
                    </button>
                    <button onClick={() => setView('Assessments')} className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg hover:bg-green-50 transition-all flex flex-col items-center justify-center space-y-2">
                         <span className="text-green-500">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 11 12 14 22 4" /><path d="M21 12v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11" /></svg>
                        </span>
                        <span className="font-semibold">Create Quiz</span>
                    </button>
                    <button onClick={() => setView('Student Engagement')} className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg hover:bg-yellow-50 transition-all flex flex-col items-center justify-center space-y-2">
                         <span className="text-yellow-500">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" /><circle cx="9" cy="7" r="4" /><path d="M22 21v-2a4 4 0 0 0-3-3.87" /><path d="M16 3.13a4 4 0 0 1 0 7.75" /></svg>
                        </span>
                        <span className="font-semibold">View Students</span>
                    </button>
                    <button onClick={() => setView('Analytics')} className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg hover:bg-red-50 transition-all flex flex-col items-center justify-center space-y-2">
                        <span className="text-red-500">
                            <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="12" x2="12" y1="20" y2="10" /><line x1="18" x2="18" y1="20" y2="4" /><line x1="6" x2="6" y1="20" y2="16" /></svg>
                        </span>
                        <span className="font-semibold">Track Progress</span>
                    </button>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
