
import React from 'react';
import type { ViewType } from '../types';
import { NAV_ITEMS } from '../constants';

interface SidebarProps {
    currentView: ViewType;
    setCurrentView: (view: ViewType) => void;
}

const LOGO_BASE64 = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAHySURBVHhe7ZtBSsRAEEf/dHYcioi4h/YgHsSLHsWDePEgXkQUQR/iUTz4wYM3qYggHgVF8CAIgiCCiLg7M80/kFl2F2l0NNATpM+g96+qprq6kP/vBwC0gPsE9BNg/AR6BNg/AZ+BPoH9E/AZ6BHYPwGfgU5A/wK88c/SA5+AnwLvgY+BL8CbwE3gY+Bb4FvgY+D74AfwffB98AvwBfAN8C3wA/AW+BHYnwA/gZ6A/RPwGegR2D8Bn4E+gT0fAZ+BTkD/AnwE+gT2T8Bnok/g/An4DPSC+wR8BvoE9k/AZ6BHYP8EfAZ6BPZPwGegR2D/BHyGnwBnwI/Au+Bj4EvgTeAm8BHwLfAt8BHwfXACfB98H/wCvAB8A3wL/AC8BX4E9ifAj0BPoP8EfAZ6BPZPwGegR2D/BHyGnwBngB/BH4GfA18CbwI3gY+Bb4FvgY+D74MT4Pvg++AX4AXgG+Bb4AfgLfAjsD8BfgI9gT0fAZ+BTkD/AnwE+gT2T8Bnok/g/An4DPSC+wR8BvoE9k/AZ6BHYP8EfAZ6BPZPwGegR2D/BHyGnwBnwI/Au+Bj4EvgTeAm8BHwLfAt8BHwfXACfB98H/wCvAB8A3wL/AC8BX4E9ifAj0BPoP8EfAZ6BPZPwGegR2D/BHyGnwBngB/BH4GfA18CbwI3gY+Bb4FvgY+D74MT4Pvg++AX4AXgG+Bb4AfgLfAjsD8BfgI9gT0fAZ+BTkD/AnwE+gT2T8Bnok/g/An4DPSC+wT8BvoE9k/AZ6BHYP8E/ATmB/g4f+QG4P/5FwBw/wB9Afsn4DPQI7B/Aj4DfYI9HwGfgU5A/wI8Av0J+H8BngA+Ar0AYAA4/wA8+gS+A28A8Bt4gAA+A08A8C3wAIAfgZ6A/RNggGfgB/A7sD8BngG+gP0T8BnoEdg/AZ+BPoE9HwGfgU5A/wI8Av0E+hPwef4EngBPAH8B/gT8BPgL4BPgL4CvAH8BvgL8BPgL4DPgL4DPAF8ArgL8BN4CeAPsE+DPgE+AvgL8BPgL4CPgL4CvAH8BngL8BN4C/AT8BaCT+BPgE8BXgE8AvwJ8BvAG8BvgL8BPgL8A3gF8BvgL8AvgK8AvgM8AngA+AugU+AggT8BHgL8BPgL8A3gF8BvgL8AvgK8AvgM8AngA+AugU+AggT8BHgL8BPgL8A3gF8BvgL8AvgM8AngA+AugU+AggT8BHgL8BPgL8A3gF8BvgL8AvgK8AvgM8AngA+AggT+A3gI8AngA8BPgL8AvgM8AvgI8AvgI8AvgK8CfgT8BNgH8BPgE+AvgE+AvgI8AvgE+AvgI8AvgL4C/AS8BfgJ8BbgJ8AnwE+AvgE+A8x+A08ADgC/AZ4BPAN4DPAN4CfgL8BPgE+AvgE+AvgI8AvgE+AvgI8BPgF8BvgE+AvgU+A8x+A08ADgC/AZ4BPAN4DPAN4CfgL8BPgE+AvgE+AvgI8AvgE+AvgI8BPgF8BvgE+AvgU+A8x+A08ADgC/AZ4BPAN4DPgT+A/AT4C/AT4C/AT4C/AT4C/AT4C/AD4C/AD4C/AH4C/AD4C/AH4C/AD4C/AD4C/AD4C/AD4C/AD4C/AD4C/AD4C/AAsBOAT4C8AAsBOAz4C/AAsBOAz4C/AD8BPgL8BPgL8A3gJ8BPgH8BPgF8CfgU8CfgJ8CfgM8CfgI8CfgE+AvgI8BPgF8BPgF8BPgE+AvgJ8BPgF8BfgJ8BPgL8CfgL8A/gJ8BfgJ8AvgL8BPgL8AvgL8A/gJ8BPgF8CfgE8A3gF8CfgT8CfgT8BHgK8AvgI8AvgK8CfgK8BPgJ8CfgL8BfgL8BfgJ8A/gJ8BPgL8AvgI8BPgD8BfgJ8BPgF8BfgL4C/AX4A/AT4C/AX4A/AX4A/AX4BfgT4A/Ab4DfAb4A/AD4BvgT4BvAD4AfAH4BfAT4DfAL4BfAb4DfAb4A/AT4A/AT4BfgL4BvAD4A/AH4BvgD8BvgL8BfAD8AfgB8BPgB8CfgT4A/Ab4A/AT4A/AD4CfAb4DfA3wD+APwE+A3wE+A3wG+A3wD+APwA+APwA+AnwG+A3wB/A3wD+AnwE+AnwG+A3wG+A3wB+APwA+AnwG+AnwB+APwB+AnwG+AnwG+A3wB+A3wB+APwB+A3wB+AnwG+A3wB+AnwG+AnwG+AnwB+APwA+AnwG+AnwB+AnwG+AnwG+A3wB+A3wB+AnwG+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+AnwB+A52r1gAAAABJRU5ErkJggg==";

const Sidebar: React.FC<SidebarProps> = ({ currentView, setCurrentView }) => {
    return (
        <div className="flex flex-col w-64 bg-white border-r border-gray-200">
            <div className="flex items-center justify-center h-20 border-b border-gray-200">
                <img src={LOGO_BASE64} alt="EduAI Logo" className="h-10 w-10" />
                <h1 className="text-xl font-bold ml-2">EduAI</h1>
            </div>
            <nav className="flex-1 px-4 py-4 space-y-2">
                {NAV_ITEMS.map((item) => (
                    <button
                        key={item.name}
                        onClick={() => setCurrentView(item.name)}
                        className={`flex items-center px-4 py-2 text-sm font-medium rounded-md w-full text-left ${
                            currentView === item.name
                                ? 'bg-indigo-100 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                        }`}
                    >
                        <span className="mr-3">{item.icon}</span>
                        {item.name}
                    </button>
                ))}
            </nav>
        </div>
    );
};

// Fix: Add default export for the component.
export default Sidebar;
