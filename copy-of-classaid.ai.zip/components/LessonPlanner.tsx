import React, { useState, useCallback } from 'react';
import Card from './common/Card';
import Button from './common/Button';
import Spinner from './common/Spinner';
import { generateLessonPlan, textToSpeech } from '../services/geminiService';

// A simple markdown to HTML converter
const Markdown: React.FC<{ content: string }> = ({ content }) => {
    const htmlContent = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n/g, '<br />');
    return <div dangerouslySetInnerHTML={{ __html: htmlContent }} />;
};

// Fix: Add audio decoding helpers for raw PCM data from Gemini API.
function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

interface LessonPlannerProps {
    grade: string;
    subject: string;
    language: string;
}

const LessonPlanner: React.FC<LessonPlannerProps> = ({ grade, subject, language }) => {
    const [topic, setTopic] = useState('');
    const [lessonPlan, setLessonPlan] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [isSpeaking, setIsSpeaking] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    const handleGenerate = useCallback(async () => {
        if (!topic) return;
        setIsLoading(true);
        setLessonPlan('');
        setIsEditing(false);
        const plan = await generateLessonPlan(topic, grade, subject, language);
        setLessonPlan(plan);
        setIsLoading(false);
    }, [topic, grade, subject, language]);
    
    // Fix: Use Web Audio API to play raw PCM audio from TTS. `new Audio()` does not work for this format.
    const handleSpeak = async () => {
        if (!lessonPlan || isSpeaking) return;
        setIsSpeaking(true);
        try {
            const plainText = lessonPlan.replace(/<[^>]*>/g, '').replace(/\*\*/g, '');
            const audioData = await textToSpeech(plainText.substring(0, 1000)); // Limit length for TTS
            if (audioData) {
                const outputAudioContext = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
                const audioBuffer = await decodeAudioData(
                    decode(audioData),
                    outputAudioContext,
                    24000,
                    1,
                );
                const source = outputAudioContext.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(outputAudioContext.destination);
                source.onended = () => setIsSpeaking(false);
                source.start();
            } else {
                setIsSpeaking(false);
            }
        } catch (error) {
            console.error("Error playing audio", error);
            setIsSpeaking(false);
        }
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">AI Lesson Planner</h1>
                <p className="mt-1 text-lg text-gray-600">Instantly generate curriculum-aligned lesson plans.</p>
            </div>

            <Card>
                <div className="flex flex-col md:flex-row gap-4 items-center">
                    <input
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder={`Enter a topic, e.g., "Photosynthesis"`}
                        className="flex-grow w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <Button onClick={handleGenerate} isLoading={isLoading} disabled={!topic}>
                        Generate Plan
                    </Button>
                </div>
            </Card>

            {(isLoading || lessonPlan) && (
                <Card>
                    {isLoading ? (
                        <Spinner />
                    ) : (
                        <div>
                            <div className="flex justify-between items-center mb-4">
                               <h2 className="text-2xl font-bold">Generated Lesson Plan</h2>
                               <div className="flex items-center space-x-2">
                                    <Button onClick={() => setIsEditing(prev => !prev)} variant="secondary">
                                        {isEditing ? (
                                             <>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"></path><polyline points="17 21 17 13 7 13 7 21"></polyline><polyline points="7 3 7 8 15 8"></polyline></svg>
                                                Save
                                            </>
                                        ) : (
                                            <>
                                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z"></path></svg>
                                                Edit
                                            </>
                                        )}
                                   </Button>
                                   <Button onClick={handleSpeak} variant="secondary" isLoading={isSpeaking} disabled={!lessonPlan || isEditing}>
                                        <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="mr-2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg>
                                       Read Aloud
                                   </Button>
                               </div>
                            </div>
                             {isEditing ? (
                                <textarea
                                    value={lessonPlan}
                                    onChange={(e) => setLessonPlan(e.target.value)}
                                    className="w-full h-96 p-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 font-mono text-sm leading-relaxed bg-gray-50"
                                    aria-label="Edit Lesson Plan"
                                />
                            ) : (
                                <div className="prose max-w-none text-gray-700 leading-relaxed">
                                    <Markdown content={lessonPlan} />
                                </div>
                            )}
                        </div>
                    )}
                </Card>
            )}
        </div>
    );
};

export default LessonPlanner;