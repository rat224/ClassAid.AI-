
import React, { useState, useCallback } from 'react';
import type { Assessment, Question, PersonalizedLearningPath } from '../types';
import Card from './common/Card';
import Button from './common/Button';
import Spinner from './common/Spinner';
import { generateAssessment, generateLearningPath } from '../services/geminiService';

interface AssessmentsProps {
    grade: string;
    subject: string;
    language: string;
}

const Assessments: React.FC<AssessmentsProps> = ({ grade, subject }) => {
    const [topic, setTopic] = useState('');
    const [assessment, setAssessment] = useState<Assessment | null>(null);
    const [isLoading, setIsLoading] = useState(false);
    const [showAnswers, setShowAnswers] = useState(false);
    
    // New state for interactivity and learning paths
    const [studentAnswers, setStudentAnswers] = useState<Record<number, string>>({});
    const [assessmentSubmitted, setAssessmentSubmitted] = useState(false);
    const [score, setScore] = useState(0);
    const [learningPath, setLearningPath] = useState<PersonalizedLearningPath | null>(null);
    const [isGeneratingPath, setIsGeneratingPath] = useState(false);

    const handleGenerate = useCallback(async () => {
        if (!topic) return;
        setIsLoading(true);
        setAssessment(null);
        setShowAnswers(false);
        setStudentAnswers({});
        setAssessmentSubmitted(false);
        setScore(0);
        setLearningPath(null);
        const result = await generateAssessment(topic, grade, subject);
        try {
            const parsedResult = JSON.parse(result);
            if (parsedResult.error) {
                console.error(parsedResult.error);
            } else {
                setAssessment(parsedResult);
            }
        } catch (e) {
            console.error("Failed to parse assessment JSON", e);
        }
        setIsLoading(false);
    }, [topic, grade, subject]);
    
    const handleAnswerChange = (questionIndex: number, answer: string) => {
        setStudentAnswers(prev => ({
            ...prev,
            [questionIndex]: answer,
        }));
    };

    const handleSubmit = () => {
        let correctAnswers = 0;
        assessment?.questions.forEach((q, index) => {
            if (studentAnswers[index]?.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase()) {
                correctAnswers++;
            }
        });
        const finalScore = (correctAnswers / (assessment?.questions.length || 1)) * 100;
        setScore(finalScore);
        setAssessmentSubmitted(true);
        setShowAnswers(true);
    };

    const handleGeneratePath = async () => {
        if (!assessment) return;
        setIsGeneratingPath(true);
        setLearningPath(null);

        const incorrectQuestions = assessment.questions
            .map((q, i) => (studentAnswers[i]?.trim().toLowerCase() !== q.correctAnswer.trim().toLowerCase() ? `#${i + 1}` : null))
            .filter(Boolean);

        const performanceSummary = `The student scored ${score.toFixed(0)}%. ${
            incorrectQuestions.length > 0
                ? `They struggled with question(s): ${incorrectQuestions.join(', ')}.`
                : 'They answered all questions correctly.'
        } Please generate a suitable follow-up plan.`;
        
        const result = await generateLearningPath(topic, grade, subject, performanceSummary);
        try {
            const parsedResult = JSON.parse(result);
            if(parsedResult.error) {
                console.error(parsedResult.error);
            } else {
                setLearningPath(parsedResult);
            }
        } catch(e) {
            console.error("Failed to parse learning path", e);
        }
        setIsGeneratingPath(false);
    };

    const renderQuestion = (q: Question, index: number) => {
        const isCorrect = assessmentSubmitted && studentAnswers[index]?.trim().toLowerCase() === q.correctAnswer.trim().toLowerCase();
    
        const getOptionStyle = (option: string) => {
            if (!assessmentSubmitted) return 'bg-gray-50 hover:bg-indigo-100';
            if (option === q.correctAnswer) return 'bg-green-100 border-green-400 border';
            if (studentAnswers[index] === option && option !== q.correctAnswer) return 'bg-red-100 border-red-400 border';
            return 'bg-gray-50';
        };
    
        return (
            <div key={index} className="mb-6 p-4 border rounded-lg">
                <p className="font-semibold mb-2">{index + 1}. {q.questionText}</p>
                {q.type === 'MULTIPLE_CHOICE' && q.options && (
                    <div className="space-y-2">
                        {q.options.map((opt, i) => (
                            <label key={i} className={`p-3 rounded flex items-center cursor-pointer transition-colors ${getOptionStyle(opt)}`}>
                                 <input
                                    type="radio"
                                    name={`question-${index}`}
                                    value={opt}
                                    checked={studentAnswers[index] === opt}
                                    onChange={() => handleAnswerChange(index, opt)}
                                    disabled={assessmentSubmitted}
                                    className="mr-3 focus:ring-indigo-500"
                                />
                                {String.fromCharCode(97 + i)}. {opt}
                            </label>
                        ))}
                    </div>
                )}
                 {q.type === 'FILL_IN_THE_BLANK' && (
                    <div className="mt-2">
                        <input
                            type="text"
                            value={studentAnswers[index] || ''}
                            onChange={(e) => handleAnswerChange(index, e.target.value)}
                            disabled={assessmentSubmitted}
                            className={`w-full p-2 border rounded-md ${assessmentSubmitted ? (isCorrect ? 'bg-green-100 border-green-400' : 'bg-red-100 border-red-400') : 'border-gray-300 focus:ring-indigo-500 focus:border-indigo-500'}`}
                        />
                        {showAnswers && (
                            <div className="mt-2 p-2 bg-green-100 text-green-800 rounded">
                                <strong>Correct Answer:</strong> {q.correctAnswer}
                            </div>
                        )}
                    </div>
                )}
            </div>
        );
    };

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">AI Assessment & Learning Path Generator</h1>
                <p className="mt-1 text-lg text-gray-600">Create quizzes, assess understanding, and generate personalized follow-up plans.</p>
            </div>
            <Card>
                <div className="flex flex-col md:flex-row gap-4 items-center">
                    <input
                        type="text"
                        value={topic}
                        onChange={(e) => setTopic(e.target.value)}
                        placeholder={`Enter a topic, e.g., "Indian Freedom Struggle"`}
                        className="flex-grow w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
                    />
                    <Button onClick={handleGenerate} isLoading={isLoading} disabled={!topic}>
                        Generate Assessment
                    </Button>
                </div>
            </Card>

            {(isLoading || assessment) && (
                <Card>
                    {isLoading ? <Spinner /> : assessment && (
                        <div>
                            <h2 className="text-2xl font-bold mb-4">{assessment.title}</h2>
                            <div>{assessment.questions.map(renderQuestion)}</div>
                            {assessment && !assessmentSubmitted && (
                                <div className="text-center mt-6">
                                    <Button onClick={handleSubmit} disabled={Object.keys(studentAnswers).length !== assessment.questions.length}>Submit Assessment</Button>
                                </div>
                            )}
                        </div>
                    )}
                </Card>
            )}

            {assessmentSubmitted && (
                <Card className="mt-6 bg-gray-50">
                    <h3 className="text-xl font-bold text-center">Assessment Result</h3>
                    <p className={`text-5xl font-bold text-center my-4 ${score >= 60 ? 'text-green-600' : 'text-red-600'}`}>{score.toFixed(0)}%</p>
                    <div className="text-center">
                        <Button onClick={handleGeneratePath} isLoading={isGeneratingPath}>
                            {score >= 80 ? 'Generate Enrichment Path' : 'Generate Personalized Review Path'}
                        </Button>
                    </div>
                </Card>
            )}

            {isGeneratingPath && <Spinner />}
            {learningPath && (
                <Card className="mt-6">
                    <h2 className="text-2xl font-bold mb-4">Your Personalized Learning Path</h2>
                    <p className="mb-6 italic text-gray-600">"{learningPath.performanceSummary}"</p>
                    <div className="space-y-4">
                        {learningPath.learningPath.map((item, index) => (
                            <div key={index} className="p-4 border rounded-lg bg-indigo-50 border-indigo-200">
                                <span className={`inline-block px-3 py-1 text-xs font-semibold rounded-full mb-2 ${
                                    item.type === 'Review' ? 'bg-yellow-200 text-yellow-800' :
                                    item.type === 'Activity' ? 'bg-green-200 text-green-800' :
                                    item.type === 'Resource' ? 'bg-blue-200 text-blue-800' :
                                    'bg-purple-200 text-purple-800'
                                }`}>
                                    {item.type}
                                </span>
                                <h4 className="font-bold text-lg text-indigo-800 mt-1">{item.title}</h4>
                                <p className="text-gray-700">{item.description}</p>
                                <p className="text-sm mt-2 text-gray-500 font-medium">Suggestion: <span className="font-normal">{item.details}</span></p>
                            </div>
                        ))}
                    </div>
                </Card>
            )}
        </div>
    );
};

export default Assessments;
