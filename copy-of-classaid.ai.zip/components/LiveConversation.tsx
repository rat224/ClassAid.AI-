
import React, { useState, useRef, useCallback, useEffect } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality, Blob as GenAIBlob } from "@google/genai";
import Button from './common/Button';
import Card from './common/Card';

// Audio Encoding & Decoding Functions
function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string) {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(data: Uint8Array, ctx: AudioContext, sampleRate: number, numChannels: number): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);
  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}


const LiveConversation: React.FC = () => {
    const [isSessionActive, setIsSessionActive] = useState(false);
    const [transcripts, setTranscripts] = useState<{ speaker: 'user' | 'model', text: string, isFinal: boolean }[]>([]);
    const [status, setStatus] = useState<'idle' | 'listening' | 'speaking'>('idle');

    const sessionPromise = useRef<Promise<any> | null>(null);
    const streamRef = useRef<MediaStream | null>(null);
    const inputAudioContext = useRef<AudioContext | null>(null);
    const outputAudioContext = useRef<AudioContext | null>(null);
    const scriptProcessor = useRef<ScriptProcessorNode | null>(null);
    const nextStartTime = useRef<number>(0);
    const sources = useRef<Set<AudioBufferSourceNode>>(new Set());

    const cleanup = useCallback(() => {
        streamRef.current?.getTracks().forEach(track => track.stop());
        inputAudioContext.current?.close();
        outputAudioContext.current?.close();
        scriptProcessor.current?.disconnect();
        sessionPromise.current = null;
        streamRef.current = null;
        inputAudioContext.current = null;
        outputAudioContext.current = null;
        scriptProcessor.current = null;
        nextStartTime.current = 0;
        sources.current.clear();
    }, []);

    const handleStopSession = useCallback(async () => {
        if (sessionPromise.current) {
            const session = await sessionPromise.current;
            session.close();
        }
        cleanup();
        setIsSessionActive(false);
        setStatus('idle');
    }, [cleanup]);

    const handleStartSession = useCallback(async () => {
        setIsSessionActive(true);
        setStatus('listening');
        setTranscripts([]);

        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        
        inputAudioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
        outputAudioContext.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
        
        let currentInputTranscription = '';
        let currentOutputTranscription = '';

        sessionPromise.current = ai.live.connect({
            model: 'gemini-2.5-flash-native-audio-preview-09-2025',
            callbacks: {
                onopen: async () => {
                    streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });
                    const source = inputAudioContext.current!.createMediaStreamSource(streamRef.current);
                    scriptProcessor.current = inputAudioContext.current!.createScriptProcessor(4096, 1, 1);
                    
                    scriptProcessor.current.onaudioprocess = (audioProcessingEvent) => {
                        const inputData = audioProcessingEvent.inputBuffer.getChannelData(0);
                        const pcmBlob: GenAIBlob = {
                            data: encode(new Uint8Array(new Int16Array(inputData.map(f => f * 32768)).buffer)),
                            mimeType: 'audio/pcm;rate=16000',
                        };
                        sessionPromise.current?.then((session) => {
                            session.sendRealtimeInput({ media: pcmBlob });
                        });
                    };
                    source.connect(scriptProcessor.current);
                    scriptProcessor.current.connect(inputAudioContext.current!.destination);
                },
                onmessage: async (message: LiveServerMessage) => {
                    // Handle transcription
                    if (message.serverContent?.inputTranscription) {
                        const { text, isFinal } = message.serverContent.inputTranscription;
                        currentInputTranscription += text;
                        setTranscripts(prev => {
                            const last = prev[prev.length - 1];
                            if (last?.speaker === 'user' && !last.isFinal) {
                                return [...prev.slice(0, -1), { speaker: 'user', text: currentInputTranscription, isFinal }];
                            }
                            return [...prev, { speaker: 'user', text, isFinal }];
                        });
                    } else if (message.serverContent?.outputTranscription) {
                        const { text, isFinal } = message.serverContent.outputTranscription;
                        currentOutputTranscription += text;
                         setTranscripts(prev => {
                            const last = prev[prev.length - 1];
                            if (last?.speaker === 'model' && !last.isFinal) {
                                return [...prev.slice(0, -1), { speaker: 'model', text: currentOutputTranscription, isFinal }];
                            }
                            return [...prev, { speaker: 'model', text, isFinal }];
                        });
                    }

                    if(message.serverContent?.turnComplete) {
                        currentInputTranscription = '';
                        currentOutputTranscription = '';
                    }

                    // Handle audio playback
                    const audioData = message.serverContent?.modelTurn?.parts[0]?.inlineData.data;
                    if (audioData) {
                        setStatus('speaking');
                        const oac = outputAudioContext.current!;
                        nextStartTime.current = Math.max(nextStartTime.current, oac.currentTime);
                        const audioBuffer = await decodeAudioData(decode(audioData), oac, 24000, 1);
                        const source = oac.createBufferSource();
                        source.buffer = audioBuffer;
                        source.connect(oac.destination);
                        source.addEventListener('ended', () => {
                            sources.current.delete(source);
                            if (sources.current.size === 0) setStatus('listening');
                        });
                        source.start(nextStartTime.current);
                        nextStartTime.current += audioBuffer.duration;
                        sources.current.add(source);
                    }

                    if (message.serverContent?.interrupted) {
                        for (const source of sources.current.values()) {
                            source.stop();
                            sources.current.delete(source);
                        }
                        nextStartTime.current = 0;
                    }
                },
                onerror: (e: ErrorEvent) => {
                    console.error("Live session error:", e);
                    handleStopSession();
                },
                onclose: (e: CloseEvent) => {
                    console.log("Live session closed");
                    cleanup();
                    setIsSessionActive(false);
                },
            },
            config: {
                responseModalities: [Modality.AUDIO],
                inputAudioTranscription: {},
                outputAudioTranscription: {},
                systemInstruction: 'You are a friendly and helpful AI co-teacher. Keep your responses concise and engaging for a classroom setting.',
            },
        });
    }, [cleanup, handleStopSession]);

    return (
        <div className="space-y-6">
            <div>
                <h1 className="text-3xl font-bold text-gray-900">Live Conversation</h1>
                <p className="mt-1 text-lg text-gray-600">Have a real-time voice conversation with your AI co-teacher.</p>
            </div>
            <Card>
                <div className="flex flex-col items-center justify-center p-4 space-y-4">
                    <Button 
                        onClick={isSessionActive ? handleStopSession : handleStartSession}
                        className={`px-8 py-4 text-lg rounded-full ${isSessionActive ? 'bg-red-600 hover:bg-red-700' : 'bg-green-600 hover:bg-green-700'}`}
                    >
                        {isSessionActive ? 'Stop Conversation' : 'Start Conversation'}
                    </Button>
                    <div className="h-8 text-gray-600 font-medium capitalize">
                        {isSessionActive ? status : 'Ready to start'}...
                    </div>
                </div>
            </Card>
            {isSessionActive && (
                <Card>
                    <h2 className="text-xl font-bold mb-4">Live Transcript</h2>
                    <div className="space-y-4 p-4 h-96 overflow-y-auto bg-gray-50 rounded-lg">
                        {transcripts.length > 0 ? transcripts.map((t, i) => (
                             <div key={i} className={`flex ${t.speaker === 'user' ? 'justify-end' : 'justify-start'}`}>
                                <div className={`p-3 rounded-lg max-w-xl ${t.speaker === 'user' ? 'bg-indigo-100 text-indigo-800' : 'bg-gray-200 text-gray-800'}`}>
                                    <span className="font-bold capitalize">{t.speaker}: </span>
                                    <span>{t.text}</span>
                                </div>
                            </div>
                        )) : (
                           <div className="flex items-center justify-center h-full text-gray-500">
                                <p>Start speaking to see the transcript...</p>
                            </div>
                        )}
                    </div>
                </Card>
            )}
        </div>
    );
};

export default LiveConversation;
