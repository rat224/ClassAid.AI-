import React from 'react';

export type ViewType = 'Dashboard' | 'Lesson Planner' | 'Assessments' | 'Student Engagement' | 'Analytics' | 'AI Assistant' | 'Live Conversation' | 'Chatbot';

export interface NavItem {
    name: ViewType;
    // Fix: Use React.ReactElement instead of JSX.Element to avoid issues with the global JSX namespace.
    icon: React.ReactElement;
}

export interface LessonPlan {
    title: string;
    objectives: string[];
    materials: string[];
    procedure: { step: number; description: string }[];
    assessment: string;
}

export enum QuestionType {
    MULTIPLE_CHOICE = 'MULTIPLE_CHOICE',
    FILL_IN_THE_BLANK = 'FILL_IN_THE_BLANK',
}

export interface Question {
    questionText: string;
    type: QuestionType;
    options?: string[];
    correctAnswer: string;
}

export interface Assessment {
    title: string;
    questions: Question[];
}

export interface Student {
    id: number;
    name: string;
    engagement: 'Engaged' | 'Distracted' | 'Confused' | 'Helping Others';
    avatar: string;
}

export interface LearningPathItem {
    type: 'Review' | 'Activity' | 'Resource' | 'Enrichment';
    title: string;
    description: string;
    details: string;
}

export interface PersonalizedLearningPath {
    performanceSummary: string;
    learningPath: LearningPathItem[];
}

export interface ChatMessage {
    role: 'user' | 'model';
    content: string;
}