
import { GoogleGenAI, Type, Modality } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

export const generateLessonPlan = async (topic: string, grade: string, subject: string, language: string): Promise<string> => {
    const prompt = `
        You are an expert curriculum designer for K-12 education in India, aligned with NCERT guidelines.
        Create a comprehensive, engaging, and detailed lesson plan for the following:
        - Grade: ${grade}
        - Subject: ${subject}
        - Topic: "${topic}"
        - Language of Instruction: ${language}

        The lesson plan should be structured with the following sections:
        1.  **Lesson Title**: A creative and relevant title.
        2.  **Learning Objectives**: 3-4 clear, measurable objectives that students should achieve by the end of the lesson.
        3.  **Materials Required**: A list of all materials needed for the lesson (e.g., textbook, whiteboard, specific props).
        4.  **Lesson Procedure**: A step-by-step guide for the teacher, including an introduction, main activity, and conclusion. Make it interactive and fun.
        5.  **Assessment/Evaluation**: A brief section on how to check for student understanding (e.g., a short quiz, an exit ticket question).

        Please format the output as clean Markdown.
    `;
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-pro',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating lesson plan:", error);
        return "Sorry, I couldn't generate a lesson plan at this moment. Please try again.";
    }
};

export const generateAssessment = async (topic: string, grade: string, subject: string): Promise<string> => {
     const prompt = `Generate a 5-question assessment on the topic "${topic}" for ${grade} ${subject}. Include 3 multiple-choice questions and 2 fill-in-the-blank questions. For multiple choice questions, provide 4 options. Clearly indicate the correct answer for each question.`;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        title: { type: Type.STRING },
                        questions: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    questionText: { type: Type.STRING },
                                    type: { type: Type.STRING, enum: ['MULTIPLE_CHOICE', 'FILL_IN_THE_BLANK'] },
                                    options: {
                                        type: Type.ARRAY,
                                        items: { type: Type.STRING }
                                    },
                                    correctAnswer: { type: Type.STRING }
                                },
                                required: ['questionText', 'type', 'correctAnswer']
                            }
                        }
                    },
                    required: ['title', 'questions']
                },
            },
        });
        return response.text;
    } catch (error) {
        console.error("Error generating assessment:", error);
        return JSON.stringify({ error: "Failed to generate assessment." });
    }
};

export const generateEngagementSuggestion = async (): Promise<string> => {
    const prompt = "A few students in the class seem distracted. Provide a short, creative, and friendly suggestion for the teacher to re-engage them. For example: 'How about a quick 1-minute stretching exercise?' or 'Let's try a quick poll on the topic!'";
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: prompt,
        });
        return response.text;
    } catch (error) {
        console.error("Error generating suggestion:", error);
        return "Try asking a quick question to re-engage students.";
    }
};

export const textToSpeech = async (text: string): Promise<string | null> => {
    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-tts",
            contents: [{ parts: [{ text: `Say with a clear and friendly tone: ${text}` }] }],
            config: {
                responseModalities: [Modality.AUDIO],
                speechConfig: {
                    voiceConfig: {
                        prebuiltVoiceConfig: { voiceName: 'Kore' },
                    },
                },
            },
        });
        const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
        return base64Audio || null;
    } catch (error) {
        console.error("Error with Text-to-Speech:", error);
        return null;
    }
};

export const generateLearningPath = async (topic: string, grade: string, subject: string, performanceSummary: string): Promise<string> => {
    const prompt = `
        You are an expert AI educator specializing in creating personalized learning paths for students from Grade 1 to 12.
        A student has just completed an assessment on the following topic and needs a follow-up learning plan.

        - Grade: ${grade}
        - Subject: ${subject}
        - Topic: "${topic}"
        - Student's Performance Summary: "${performanceSummary}"

        Based on this performance, create a personalized learning path.
        The path should include a mix of activities to reinforce understanding and, if the performance was strong, enrichment activities to challenge the student.
        - If the student struggled, focus on 'Review' activities, simplified 'Resources', and hands-on 'Activities'.
        - If the student did well, include 'Enrichment' activities, advanced 'Resources', and project-based 'Activities'.

        Provide a brief summary of your recommendation and a list of 3-4 learning path items.
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-pro",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                responseSchema: {
                    type: Type.OBJECT,
                    properties: {
                        performanceSummary: { 
                            type: Type.STRING,
                            description: "A brief summary analyzing the student's performance and the recommended focus for the learning path."
                        },
                        learningPath: {
                            type: Type.ARRAY,
                            items: {
                                type: Type.OBJECT,
                                properties: {
                                    type: { type: Type.STRING, enum: ['Review', 'Activity', 'Resource', 'Enrichment'] },
                                    title: { type: Type.STRING },
                                    description: { type: Type.STRING },
                                    details: { type: Type.STRING, description: "Specific instructions, e.g., 'Read chapter 5.1' or 'Watch the video at [link]'." }
                                },
                                required: ['type', 'title', 'description', 'details']
                            }
                        }
                    },
                    required: ['performanceSummary', 'learningPath']
                },
            },
        });
        return response.text;
    } catch (error) {
        console.error("Error generating learning path:", error);
        return JSON.stringify({ error: "Failed to generate learning path." });
    }
};

export const getChatResponse = async (prompt: string, thinkingMode: boolean): Promise<string> => {
    const model = thinkingMode ? 'gemini-2.5-pro' : 'gemini-2.5-flash';
    const config = thinkingMode ? { thinkingConfig: { thinkingBudget: 32768 } } : {};

    try {
        const response = await ai.models.generateContent({
            model,
            contents: prompt,
            config,
        });
        return response.text;
    } catch (error) {
        console.error("Error getting chat response:", error);
        return "I'm sorry, I encountered an error while processing your request.";
    }
};

export const transcribeAudio = async (audioBase64: string, mimeType: string): Promise<string> => {
    try {
        const audioPart = {
            inlineData: {
                mimeType,
                data: audioBase64,
            },
        };
        const textPart = {
            text: "Transcribe the following audio.",
        };

        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: { parts: [audioPart, textPart] },
        });
        return response.text;
    } catch (error) {
        console.error("Error transcribing audio:", error);
        return "Audio transcription failed. Please try again.";
    }
};
